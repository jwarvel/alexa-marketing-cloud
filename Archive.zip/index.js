'use strict';
module.change_code = 1;
var _ = require('lodash');
var Alexa = require('alexa-app');
var app = new Alexa.app('marketingcloud');
var MCDataHelper = require('./mc-data-helper');

app.launch(function (req, res) {
    var prompt = 'I can check Marketing Cloud status for you.  Currently, I can get transaction count and issue counts.';
    res.say(prompt).reprompt(prompt).shouldEndSession(false);
});

app.intent('transactions', {
        'slots': {
        },
        'utterances': ['{|get} {transactions|transaction|messages|message} {|count|counts} {|today|for today|}']
    },
    function (req, res) {

        var reprompt =  'What would you like to know?  Say transaction count or issue count.';
        var mcDataHelper = new MCDataHelper();
        mcDataHelper.getTransactionCount().then(function (response) {
            console.log(response);
            res.say(mcDataHelper.formatTransactionCount(response)).shouldEndSession(false).send();
        }).catch(function (err) {
                console.log(err.statusCode);
                var prompt = 'I couldn\'t get the transaction count ';
                res.say(prompt).reprompt(reprompt).shouldEndSession(false).send();
            });
        return false;
    }

);

app.intent('issuesDay', {
        'slots': {
        },
        'utterances': ['{|get} {issues|issue} {|count} {|last} {|day|24 hours}']
    },
    function (req, res) {

        var reprompt = 'What would you like to know?  Say transaction count or issue count.';
        var mcDataHelper = new MCDataHelper();
        mcDataHelper.getIssueCounts().then(function (response) {

            res.say(mcDataHelper.formatIssueCounts(response)).shouldEndSession(false).send();
        }).catch(function (err) {
                console.log(err.statusCode);
                var prompt = 'I couldn\'t get the issue counts ';
                res.say(prompt).reprompt(reprompt).shouldEndSession(false).send();
            });
        return false;
    }

);


//hack to support custom utterances in utterance expansion string
//console.log(app.utterances().replace(/\{\-\|/g, '{'));
module.exports = app;
